---
title: "Heisenbugs from Shared State and Time"
date: "2025-03-04"
author: "Blendistry"
image: "https://www.edureka.co/blog/wp-content/uploads/2019/08/hero-snapshot-debugger-300x165.png"
excerpt: "Heisenbugs from Shared State and Time: A practical, theory-first walkthrough on Non-deterministic failures caused by races, caches, and clocks—and how to pin them down., with a tiny, focused code snippet and an actionable checklist."
category: "Debugging"
---
# Heisenbugs from Shared State and Time

Non-deterministic failures caused by races, caches, and clocks—and how to pin them down.

### Why this happens
Humans guess; good debuggers reduce uncertainty systematically.
### Symptoms you’ll notice
Hours lost chasing red herrings; bugs that 'disappear' when logged or breakpoints added.
### Mental model
Treat debugging as experiments guided by invariants and binary search over the state space.
### Quick checklist
- Define the failure as a precise observable
- Halve the search space (time, commits, codepaths)
- Create a 10–20 line repro
- Add structured logs with correlation IDs
- Freeze time/caches to remove nondeterminism

### Small code snippet
```python
# minimal bisect-able test
def is_bad(commit):
return run_tests(commit)
!= 0
```
### Pitfalls
Changing two variables at once; trusting logs that are buffered or reordered; ignoring the baseline.
### What to do next
Invest in tracing; codify a 'minimal repro' template in your org wiki.
