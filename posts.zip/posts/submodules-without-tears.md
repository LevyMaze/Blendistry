---
title: "Submodules Without Tears"
date: "2025-03-28"
author: "Blendistry"
image: "https://blog.nashtechglobal.com/wp-content/uploads/2024/01/git.png"
excerpt: "Submodules Without Tears: A practical, theory-first walkthrough on How to version external repos reliably using submodules and CI sanity checks., with a tiny, focused code snippet and an actionable checklist."
category: "Git-Github"
---
# Submodules Without Tears

How to version external repos reliably using submodules and CI sanity checks.

### Why this happens
History hygiene improves review quality and makes regressions findable.
### Symptoms you’ll notice
Hard-to-read diffs, merge bubbles, or lost work after aggressive resets.
### Mental model
Think of Git as a graph. Tools like rebase, reflog, and bisect reshape or traverse that graph safely.
### Quick checklist
- Keep main protected with required checks
- Prefer rebase/merge rules per repo
- Tag releases; sign important commits
- Use bisect on testable failures
- Document branch/PR conventions

### Small code snippet
```bash
# recover a lost branch
git reflog
git checkout -b rescued HEAD@{3}
```
### Pitfalls
Force-pushing shared branches; rebasing public history; ignoring reflog expiry.
### What to do next
Automate branch protections and PR templates across repos.
