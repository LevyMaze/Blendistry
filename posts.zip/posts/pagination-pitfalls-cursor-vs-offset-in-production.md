---
title: "Pagination Pitfalls: Cursor vs Offset in Production"
date: "2025-02-02"
author: "Blendistry"
image: "https://www.simplilearn.com/ice9/free_resources_article_thumb/How_to_Become_a_Back_End_Developer.jpg"
excerpt: "Pagination Pitfalls: Cursor vs Offset in Production: A practical, theory-first walkthrough on Why cursors scale better than offsets and how to implement stable pagination under writes., with a tiny, focused code snippet and an actionable checklist."
category: "Backend"
---
# Pagination Pitfalls: Cursor vs Offset in Production

Why cursors scale better than offsets and how to implement stable pagination under writes.

### Why this happens
Distributed systems fail in partial, messy ways—network timeouts, retries, duplicate deliveries.
### Symptoms you’ll notice
Duplicate records, nondeterministic 5xx spikes, or increased latency under retries.
### Mental model
Model requests as messages and your service as a state machine; make operations idempotent and retry-safe.
### Quick checklist
- Define idempotent semantics per endpoint
- Persist dedupe keys with TTL
- Include request hash in stored value
- Return previous result for duplicates
- Instrument retries and key collisions

### Small code snippet
express pseudo-code for idempotency
```js

app.post('/payments',
 async (req, res) => {
  const key = 
  req.header('Idempotency-Key');
  const seen = await 
  store.get(key);
  if (seen) return 
  res.json(seen);
  const result = await 
  charge(req.body);
  await store.set(key, result);
  res.json(result);
});
```
### Pitfalls
Storing only success responses; forgetting to scope keys by user/account; unbounded key growth.
### What to do next
Adopt a retry policy with exponential backoff and jitter; document idempotency per API.
