---
title: "Validating Webhooks Securely: Signatures and Replays"
date: "2025-02-11"
author: "Blendistry"
image: "https://cyclr.com/nitropack_static/VuXxlbQNhqQgnktlfMtCedOWhlGohlKT/assets/images/optimized/rev-1d1934b/cyclr.com/wp-content/uploads/2024/05/Webhook-Examples-1024x548.png"
excerpt: "Validating Webhooks Securely: Signatures and Replays: A practical, theory-first walkthrough on Reject forged or replayed webhook calls with HMAC signatures, timestamps, and idempotency., with a tiny, focused code snippet and an actionable checklist."
category: "Backend"
---
# Validating Webhooks Securely: Signatures and Replays

Reject forged or replayed webhook calls with HMAC signatures, timestamps, and idempotency.

### Why this happens
Distributed systems fail in partial, messy ways—network timeouts, retries, duplicate deliveries.
### Symptoms you’ll notice
Duplicate records, nondeterministic 5xx spikes, or increased latency under retries.
### Mental model
Model requests as messages and your service as a state machine; make operations idempotent and retry-safe.
### Quick checklist
- Define idempotent semantics per endpoint
- Persist dedupe keys with TTL
- Include request hash in stored value
- Return previous result for duplicates
- Instrument retries and key collisions

### Small code snippet
```js
// express pseudo-code for idempotency
app.post('/payments', async (req, res) => {
  const key = req.header('Idempotency-Key');
  const seen = await store.get(key);
  if (seen) return res.json(seen);
  const result = await charge(req.body);
  await store.set(key, result);
  res.json(result);
});
```
### Pitfalls
Storing only success responses; forgetting to scope keys by user/account; unbounded key growth.
### What to do next
Adopt a retry policy with exponential backoff and jitter; document idempotency per API.
