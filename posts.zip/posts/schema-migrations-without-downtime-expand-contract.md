---
title: "Schema Migrations Without Downtime: Expand/Contract"
date: "2025-02-26"
author: "Blendistry"
image: "https://cdni.iconscout.com/illustration/premium/thumb/database-illustration-svg-png-download-4993186.png"
excerpt: "Schema Migrations Without Downtime: Expand/Contract: A practical, theory-first walkthrough on Ship schema changes safely with forward/backward compatibility and dual writes., with a tiny, focused code snippet and an actionable checklist."
category: "Database"
---
# Schema Migrations Without Downtime: Expand/Contract

Ship schema changes safely with forward/backward compatibility and dual writes.

### Why this happens
Query planners need the right metadata and predicates; without it, they do expensive scans or deadlock.
### Symptoms you’ll notice
Slow endpoints, high CPU on DB, lock timeouts, or inconsistent reads under load.
### Mental model
See data access as sets and constraints; shape queries and indexes to match predicates and ordering.
### Quick checklist
- Collect slow query logs and EXPLAIN plans
- Batch and cache to avoid N+1 patterns
- Use partial/covering indexes for hot paths
- Choose isolation level per workload
- Plan expand/contract migrations

### Small code snippet
```sql
-- PostgreSQL: partial index example
CREATE INDEX CONCURRENTLY idx_users_active
ON users (last_seen)
WHERE active = true;
```
### Pitfalls
Indexes that don't match WHERE clauses; adding columns in one step causing locks; phantom reads under Repeatable Read.
### What to do next
Write migration runbooks; exercise them on staging with production-like data volumes.
