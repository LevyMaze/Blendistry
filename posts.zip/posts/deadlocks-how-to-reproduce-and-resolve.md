---
title: "Deadlocks: How to Reproduce and Resolve"
date: "2025-02-20"
author: "Blendistry"
image: "https://kinsta.com/wp-content/uploads/2022/02/postgres-logo.png"
excerpt: "Deadlocks: How to Reproduce and Resolve: A practical, theory-first walkthrough on Simulate deadlocks locally, interpret wait graphs, and fix ordering to prevent them., with a tiny, focused code snippet and an actionable checklist."
category: "Database"
---
# Deadlocks: How to Reproduce and Resolve

Simulate deadlocks locally, interpret wait graphs, and fix ordering to prevent them.

### Why this happens
Query planners need the right metadata and predicates; without it, they do expensive scans or deadlock.
### Symptoms you’ll notice
Slow endpoints, high CPU on DB, lock timeouts, or inconsistent reads under load.
### Mental model
See data access as sets and constraints; shape queries and indexes to match predicates and ordering.
### Quick checklist
- Collect slow query logs and EXPLAIN plans
- Batch and cache to avoid N+1 patterns
- Use partial/covering indexes for hot paths
- Choose isolation level per workload
- Plan expand/contract migrations

### Small code snippet
```sql
-- PostgreSQL: partial index example
CREATE INDEX CONCURRENTLY 
idx_users_active
ON users (last_seen)
WHERE active = true;
```
### Pitfalls
Indexes that don't match WHERE clauses; adding columns in one step causing locks; phantom reads under Repeatable Read.
### What to do next
Write migration runbooks; exercise them on staging with production-like data volumes.
